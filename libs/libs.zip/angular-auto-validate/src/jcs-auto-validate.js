(function (angular) {
    'use strict';

    angular.module('jcs-autoValidate', []);
}(angular));
